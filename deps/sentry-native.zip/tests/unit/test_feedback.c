#include "sentry_attachment.h"
#include "sentry_envelope.h"
#include "sentry_hint.h"
#include "sentry_path.h"
#include "sentry_testsupport.h"
#include "sentry_transport.h"

typedef struct {
    uint64_t called;
    sentry_stringbuilder_t serialized_envelope;
} sentry_feedback_testdata_t;

static void
send_envelope_test_feedback(sentry_envelope_t *envelope, void *_data)
{
    sentry_feedback_testdata_t *data = _data;
    data->called += 1;
    sentry__envelope_serialize_into_stringbuilder(
        envelope, &data->serialized_envelope);
    sentry_envelope_free(envelope);
}

static void
setup_feedback_test_with_before_send(sentry_feedback_testdata_t *testdata,
    sentry_before_send_feedback_function_t func, void *user_data)
{
    testdata->called = 0;
    sentry__stringbuilder_init(&testdata->serialized_envelope);

    SENTRY_TEST_OPTIONS_NEW(options);
    sentry_options_set_auto_session_tracking(options, false);
    sentry_options_set_dsn(options, "https://foo@sentry.invalid/42");
    sentry_options_set_release(options, "my-app@1.2.3");
    sentry_options_set_environment(options, "staging");
    sentry_options_set_before_send_feedback(options, func, user_data);
    sentry_transport_t *transport
        = sentry_transport_new(send_envelope_test_feedback);
    sentry_transport_set_state(transport, testdata);
    sentry_options_set_transport(options, transport);

    sentry_init(options);
}

static void
setup_feedback_test(sentry_feedback_testdata_t *testdata)
{
    setup_feedback_test_with_before_send(testdata, 0, NULL);
}

SENTRY_TEST(feedback_without_hint)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test(&testdata);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_capture_feedback(feedback);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    TEST_CHECK(strstr(serialized, "\"type\":\"feedback\"") != NULL);
    TEST_CHECK(strstr(serialized, "\"type\":\"attachment\"") == NULL);
    sentry_free(serialized);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

SENTRY_TEST(feedback_with_null_hint)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test(&testdata);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_capture_feedback_with_hint(feedback, NULL);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    TEST_CHECK(strstr(serialized, "\"type\":\"feedback\"") != NULL);
    TEST_CHECK(strstr(serialized, "\"type\":\"attachment\"") == NULL);
    sentry_free(serialized);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

SENTRY_TEST(feedback_with_file_attachment)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test(&testdata);

    sentry_path_t *attachment_path
        = sentry__path_from_str(SENTRY_TEST_PATH_PREFIX ".feedback-attachment");
    sentry__path_write_buffer(attachment_path, "feedback data", 13);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_hint_t *hint = sentry_hint_new();
    TEST_CHECK(hint != NULL);

    sentry_attachment_t *attachment = sentry_hint_attach_file(
        hint, SENTRY_TEST_PATH_PREFIX ".feedback-attachment");
    TEST_CHECK(attachment != NULL);

    sentry_capture_feedback_with_hint(feedback, hint);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    TEST_CHECK(strstr(serialized, "\"type\":\"feedback\"") != NULL);
    TEST_CHECK(strstr(serialized,
                   "{\"type\":\"attachment\",\"length\":13,"
                   "\"filename\":\".feedback-attachment\"}\n"
                   "feedback data")
        != NULL);
    sentry_free(serialized);

    sentry_close();

    sentry__path_remove(attachment_path);
    sentry__path_free(attachment_path);

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

SENTRY_TEST(feedback_with_bytes_attachment)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test(&testdata);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_hint_t *hint = sentry_hint_new();
    TEST_CHECK(hint != NULL);

    const char binary_data[] = "binary\0data\0here";
    sentry_attachment_t *attachment = sentry_hint_attach_bytes(
        hint, binary_data, sizeof(binary_data) - 1, "binary.dat");
    TEST_CHECK(attachment != NULL);

    sentry_capture_feedback_with_hint(feedback, hint);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    TEST_CHECK(strstr(serialized, "\"type\":\"feedback\"") != NULL);
    TEST_CHECK(strstr(serialized,
                   "{\"type\":\"attachment\",\"length\":16,"
                   "\"filename\":\"binary.dat\"}")
        != NULL);
    TEST_CHECK(strstr(serialized, "binary") != NULL);
    sentry_free(serialized);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

SENTRY_TEST(feedback_with_multiple_attachments)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test(&testdata);

    sentry_path_t *file1
        = sentry__path_from_str(SENTRY_TEST_PATH_PREFIX ".feedback-file1");
    sentry_path_t *file2
        = sentry__path_from_str(SENTRY_TEST_PATH_PREFIX ".feedback-file2");
    sentry__path_write_buffer(file1, "file1 content", 13);
    sentry__path_write_buffer(file2, "file2 content", 13);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_hint_t *hint = sentry_hint_new();
    TEST_CHECK(hint != NULL);

    sentry_attachment_t *attachment1 = sentry_hint_attach_file(
        hint, SENTRY_TEST_PATH_PREFIX ".feedback-file1");
    TEST_CHECK(attachment1 != NULL);

    sentry_attachment_t *attachment2
        = sentry_hint_attach_bytes(hint, "bytes content", 13, "bytes.txt");
    TEST_CHECK(attachment2 != NULL);

    sentry_attachment_t *attachment3 = sentry_hint_attach_file(
        hint, SENTRY_TEST_PATH_PREFIX ".feedback-file2");
    TEST_CHECK(attachment3 != NULL);

    sentry_capture_feedback_with_hint(feedback, hint);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    TEST_CHECK(strstr(serialized, "\"type\":\"feedback\"") != NULL);
    TEST_CHECK(strstr(serialized, "\"filename\":\".feedback-file1\"") != NULL);
    TEST_CHECK(strstr(serialized, "\"filename\":\"bytes.txt\"") != NULL);
    TEST_CHECK(strstr(serialized, "\"filename\":\".feedback-file2\"") != NULL);
    TEST_CHECK(strstr(serialized, "file1 content") != NULL);
    TEST_CHECK(strstr(serialized, "bytes content") != NULL);
    TEST_CHECK(strstr(serialized, "file2 content") != NULL);
    sentry_free(serialized);

    sentry_close();

    sentry__path_remove(file1);
    sentry__path_remove(file2);
    sentry__path_free(file1);
    sentry__path_free(file2);

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

SENTRY_TEST(feedback_carries_scope_data)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test(&testdata);

    sentry_set_tag("scoped_tag", "from_scope");
    sentry_set_user(sentry_value_new_user("id-42", "alice", NULL, NULL));
    sentry_value_t game_context = sentry_value_new_object();
    sentry_value_set_by_key(
        game_context, "engine_version", sentry_value_new_string("4.5"));
    sentry_set_context("game", game_context);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_capture_feedback(feedback);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    const char *item = strstr(serialized, "{\"type\":\"feedback\"");
    TEST_ASSERT(item != NULL);
    TEST_CHECK(strstr(item, "\"release\":\"my-app@1.2.3\"") != NULL);
    TEST_CHECK(strstr(item, "\"environment\":\"staging\"") != NULL);
    TEST_CHECK(strstr(item, "\"scoped_tag\":\"from_scope\"") != NULL);
    TEST_CHECK(strstr(item, "\"id\":\"id-42\"") != NULL);
    TEST_CHECK(strstr(item, "\"trace\"") != NULL);
    TEST_CHECK(strstr(item, "\"game\":{\"engine_version\":\"4.5\"}") != NULL);
    TEST_CHECK(strstr(item, "\"level\":\"info\"") != NULL);
    sentry_free(serialized);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

SENTRY_TEST(feedback_with_scope_attachment)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test(&testdata);

    const char scope_data[] = "scope content";
    sentry_attachment_t *attachment
        = sentry_attach_bytes(scope_data, sizeof(scope_data) - 1, "scope.txt");
    TEST_CHECK(attachment != NULL);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_capture_feedback(feedback);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    TEST_CHECK(strstr(serialized, "\"type\":\"feedback\"") != NULL);
    TEST_CHECK(strstr(serialized,
                   "{\"type\":\"attachment\",\"length\":13,"
                   "\"filename\":\"scope.txt\"}\n"
                   "scope content")
        != NULL);
    sentry_free(serialized);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

SENTRY_TEST(feedback_with_scope_and_hint_attachments)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test(&testdata);

    const char scope_data[] = "scope content";
    sentry_attachment_t *scope_attachment
        = sentry_attach_bytes(scope_data, sizeof(scope_data) - 1, "scope.txt");
    TEST_CHECK(scope_attachment != NULL);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_hint_t *hint = sentry_hint_new();
    TEST_CHECK(hint != NULL);

    const char hint_data[] = "hint content";
    sentry_attachment_t *hint_attachment = sentry_hint_attach_bytes(
        hint, hint_data, sizeof(hint_data) - 1, "hint.txt");
    TEST_CHECK(hint_attachment != NULL);

    sentry_capture_feedback_with_hint(feedback, hint);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    TEST_CHECK(strstr(serialized, "\"type\":\"feedback\"") != NULL);
    TEST_CHECK(strstr(serialized, "\"filename\":\"scope.txt\"") != NULL);
    TEST_CHECK(strstr(serialized, "scope content") != NULL);
    TEST_CHECK(strstr(serialized, "\"filename\":\"hint.txt\"") != NULL);
    TEST_CHECK(strstr(serialized, "hint content") != NULL);
    sentry_free(serialized);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

SENTRY_TEST(feedback_with_scope)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test(&testdata);

    sentry_set_tag("global_tag", "from_global");

    sentry_scope_t *scope = sentry_scope_new();
    sentry_scope_set_tag(scope, "scoped_tag", "from_scope");
    sentry_scope_set_user(
        scope, sentry_value_new_user("id-42", "alice", NULL, NULL));

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_uuid_t feedback_id
        = sentry_scope_capture_feedback(scope, feedback, NULL);
    TEST_CHECK(!sentry_uuid_is_nil(&feedback_id));

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    const char *item = strstr(serialized, "{\"type\":\"feedback\"");
    TEST_ASSERT(item != NULL);
    TEST_CHECK(strstr(item, "\"scoped_tag\":\"from_scope\"") != NULL);
    TEST_CHECK(strstr(item, "\"id\":\"id-42\"") != NULL);
    TEST_CHECK(strstr(item, "\"global_tag\":\"from_global\"") != NULL);
    TEST_CHECK(strstr(item, "\"release\":\"my-app@1.2.3\"") != NULL);

    char feedback_id_str[37];
    sentry_uuid_as_string(&feedback_id, feedback_id_str);
    TEST_CHECK(strstr(serialized, feedback_id_str) != NULL);
    sentry_free(serialized);

    sentry_scope_free(scope);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

SENTRY_TEST(feedback_with_one_shot_scope)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test(&testdata);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    // A local scope is one-shot: it is consumed and freed by the capture. ASan
    // fails the test if the scope leaks.
    sentry_scope_t *local_scope = sentry_local_scope_new();
    sentry_scope_set_tag(local_scope, "scoped_tag", "from_scope");

    sentry_uuid_t feedback_id
        = sentry_scope_capture_feedback(local_scope, feedback, NULL);
    TEST_CHECK(!sentry_uuid_is_nil(&feedback_id));

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    const char *item = strstr(serialized, "{\"type\":\"feedback\"");
    TEST_ASSERT(item != NULL);
    TEST_CHECK(strstr(item, "\"scoped_tag\":\"from_scope\"") != NULL);
    sentry_free(serialized);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

SENTRY_TEST(feedback_with_scope_and_hint)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test(&testdata);

    sentry_scope_t *local_scope = sentry_local_scope_new();
    sentry_scope_set_tag(local_scope, "scoped_tag", "from_scope");

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_hint_t *hint = sentry_hint_new();
    TEST_CHECK(hint != NULL);
    sentry_attachment_t *attachment
        = sentry_hint_attach_bytes(hint, "hint content", 12, "hint.txt");
    TEST_CHECK(attachment != NULL);

    sentry_uuid_t feedback_id
        = sentry_scope_capture_feedback(local_scope, feedback, hint);
    TEST_CHECK(!sentry_uuid_is_nil(&feedback_id));

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    const char *item = strstr(serialized, "{\"type\":\"feedback\"");
    TEST_ASSERT(item != NULL);
    TEST_CHECK(strstr(item, "\"scoped_tag\":\"from_scope\"") != NULL);
    TEST_CHECK(strstr(serialized, "\"filename\":\"hint.txt\"") != NULL);
    TEST_CHECK(strstr(serialized, "hint content") != NULL);
    sentry_free(serialized);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

static sentry_value_t
before_send_feedback_inspect(
    sentry_value_t feedback, sentry_hint_t *hint, void *user_data)
{
    (void)hint;
    uint64_t *called = user_data;
    *called += 1;

    // the hook runs after scopes have been applied
    TEST_CHECK_STRING_EQUAL(
        sentry_value_as_string(sentry_value_get_by_key(feedback, "release")),
        "my-app@1.2.3");
    TEST_CHECK_STRING_EQUAL(
        sentry_value_as_string(sentry_value_get_by_key(
            sentry_value_get_by_key(feedback, "tags"), "global_tag")),
        "from_global");

    return feedback;
}

SENTRY_TEST(feedback_before_send_receives_scope_data)
{
    sentry_feedback_testdata_t testdata;
    uint64_t before_send_called = 0;
    setup_feedback_test_with_before_send(
        &testdata, before_send_feedback_inspect, &before_send_called);

    sentry_set_tag("global_tag", "from_global");

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_capture_feedback(feedback);

    TEST_CHECK_INT_EQUAL(before_send_called, 1);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    TEST_CHECK(strstr(serialized, "{\"type\":\"feedback\"") != NULL);
    sentry_free(serialized);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

static sentry_value_t
before_send_feedback_modify(
    sentry_value_t feedback, sentry_hint_t *hint, void *user_data)
{
    (void)hint;
    (void)user_data;
    sentry_value_set_by_key(
        feedback, "logger", sentry_value_new_string("modified-by-hook"));
    return feedback;
}

SENTRY_TEST(feedback_before_send_can_modify)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test_with_before_send(
        &testdata, before_send_feedback_modify, NULL);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_capture_feedback(feedback);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    const char *item = strstr(serialized, "{\"type\":\"feedback\"");
    TEST_ASSERT(item != NULL);
    TEST_CHECK(strstr(item, "\"logger\":\"modified-by-hook\"") != NULL);
    sentry_free(serialized);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

static sentry_value_t
before_send_feedback_discard(
    sentry_value_t feedback, sentry_hint_t *hint, void *user_data)
{
    (void)hint;
    uint64_t *called = user_data;
    *called += 1;
    sentry_value_decref(feedback);
    return sentry_value_new_null();
}

SENTRY_TEST(feedback_before_send_discards_with_scope_and_hint)
{
    sentry_feedback_testdata_t testdata;
    uint64_t before_send_called = 0;
    setup_feedback_test_with_before_send(
        &testdata, before_send_feedback_discard, &before_send_called);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    // The scope and the hint are consumed by the discarding capture;
    // ASan fails the test if they leak.
    sentry_scope_t *local_scope = sentry_local_scope_new();
    sentry_scope_attach_bytes(local_scope, "dropped", 7, "dropped.txt");

    sentry_hint_t *hint = sentry_hint_new();
    sentry_hint_attach_bytes(hint, "dropped", 7, "hint.txt");

    sentry_uuid_t feedback_id
        = sentry_scope_capture_feedback(local_scope, feedback, hint);

    TEST_CHECK_INT_EQUAL(before_send_called, 1);
    TEST_CHECK(sentry_uuid_is_nil(&feedback_id));
    TEST_CHECK_INT_EQUAL(testdata.called, 0);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    TEST_CHECK(strstr(serialized, "\"type\":\"feedback\"") == NULL);
    sentry_free(serialized);

    sentry_close();
}

static sentry_value_t
before_send_feedback_attach(
    sentry_value_t feedback, sentry_hint_t *hint, void *user_data)
{
    (void)user_data;
    sentry_hint_attach_bytes(hint, "from hook", 9, "hook.txt");
    return feedback;
}

SENTRY_TEST(feedback_before_send_can_attach_to_hint)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test_with_before_send(
        &testdata, before_send_feedback_attach, NULL);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    sentry_hint_t *hint = sentry_hint_new();
    sentry_hint_attach_bytes(hint, "before hook", 11, "before.txt");

    // The callback adds an additional attachment to the hint.
    sentry_capture_feedback_with_hint(feedback, hint);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    TEST_CHECK(strstr(serialized, "\"filename\":\"before.txt\"") != NULL);
    TEST_CHECK(strstr(serialized, "before hook") != NULL);
    TEST_CHECK(strstr(serialized, "\"filename\":\"hook.txt\"") != NULL);
    TEST_CHECK(strstr(serialized, "from hook") != NULL);
    sentry_free(serialized);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}

SENTRY_TEST(feedback_before_send_can_attach_without_hint)
{
    sentry_feedback_testdata_t testdata;
    setup_feedback_test_with_before_send(
        &testdata, before_send_feedback_attach, NULL);

    sentry_uuid_t event_id
        = sentry_uuid_from_string("4c035723-8638-4c3a-923f-2ab9d08b4018");
    sentry_value_t feedback = sentry_value_new_feedback(
        "test message", "test@example.com", "Test User", &event_id);

    // No hint is passed; capture should create one so the callback can attach
    // additional files to it.
    sentry_capture_feedback(feedback);

    char *serialized
        = sentry_stringbuilder_take_string(&testdata.serialized_envelope);
    TEST_CHECK(strstr(serialized, "\"filename\":\"hook.txt\"") != NULL);
    TEST_CHECK(strstr(serialized, "from hook") != NULL);
    sentry_free(serialized);

    sentry_close();

    TEST_CHECK_INT_EQUAL(testdata.called, 1);
}
