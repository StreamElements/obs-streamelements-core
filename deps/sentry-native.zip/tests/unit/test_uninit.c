#include "sentry_core.h"
#include "sentry_envelope.h"
#include "sentry_options.h"
#include "sentry_sync.h"
#include "sentry_testsupport.h"
#include "sentry_transport.h"

SENTRY_TEST(uninitialized)
{
    // make sure the public sentry API does not crash when called without a
    // `sentry_init`
    sentry_clear_modulecache();
    sentry_user_consent_give();
    sentry_user_consent_revoke();
    sentry_user_consent_reset();
    TEST_CHECK(sentry_user_consent_get() == SENTRY_USER_CONSENT_UNKNOWN);
    sentry_uuid_t uuid = sentry_capture_event(sentry_value_new_event());
    TEST_CHECK(sentry_uuid_is_nil(&uuid));
    sentry_handle_exception(NULL);
    sentry_add_breadcrumb(sentry_value_new_breadcrumb("foo", "bar"));
    sentry_set_user(sentry_value_new_object());
    sentry_remove_user();
    sentry_set_tag("foo", "bar");
    sentry_remove_tag("foo");
    sentry_set_extra("foo", sentry_value_new_null());
    sentry_remove_extra("foo");
    sentry_set_attribute("foo",
        sentry_value_new_attribute(sentry_value_new_string("bar"), NULL));
    sentry_remove_attribute("foo");
    sentry_set_context("foo", sentry_value_new_object());
    sentry_remove_context("foo");
    sentry_set_fingerprint("foo", "bar", NULL);
    sentry_remove_fingerprint();
    sentry_set_transaction("foo");
    sentry_set_level(SENTRY_LEVEL_DEBUG);
    sentry_start_session();
    sentry_end_session();
    sentry_close();
}

SENTRY_TEST(empty_transport)
{
    SENTRY_TEST_OPTIONS_NEW(options);
    sentry_options_set_transport(options, NULL);

    TEST_CHECK(sentry_init(options) == 0);

    sentry_value_t event = sentry_value_new_message_event(
        SENTRY_LEVEL_WARNING, NULL, "some message");
    sentry_uuid_t id = sentry_capture_event(event);
    TEST_CHECK(!sentry_uuid_is_nil(&id));

    SENTRY_WITH_OPTIONS (runtime_options) {
        TEST_ASSERT(!!runtime_options->transport);
        sentry__transport_suspend(runtime_options->transport);
        sentry__transport_send_envelope(
            runtime_options->transport, sentry__envelope_new());
        TEST_CHECK(sentry__atomic_fetch(&runtime_options->run->retain));
    }

    sentry_close();
}

SENTRY_TEST(invalid_dsn)
{
    SENTRY_TEST_OPTIONS_NEW(options);
    sentry_options_set_dsn(options, "not a valid dsn");

    TEST_CHECK(sentry_init(options) == 0);

    sentry_value_t event = sentry_value_new_message_event(
        SENTRY_LEVEL_WARNING, NULL, "some message");
    sentry_uuid_t id = sentry_capture_event(event);
    TEST_CHECK(!sentry_uuid_is_nil(&id));

    sentry_close();
}

SENTRY_TEST(invalid_proxy)
{
    SENTRY_TEST_OPTIONS_NEW(options);
    sentry_options_set_proxy(options, "invalid");

    TEST_CHECK(sentry_init(options) == 0);

    sentry_value_t event = sentry_value_new_message_event(
        SENTRY_LEVEL_WARNING, NULL, "some message");
    sentry_uuid_t id = sentry_capture_event(event);
    TEST_CHECK(!sentry_uuid_is_nil(&id));

    sentry_close();
}
